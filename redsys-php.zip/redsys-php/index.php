<?php
echo "<h1>Servidor Redsys Test</h1>";
echo "<ul>";
echo "<li><a href='ejemploGeneraPet.php'>Generar parámetros</a></li>";
echo "<li><a href='ejemploRecepcionaPet.php'>Receptor notificación</a></li>";
echo "</ul>";
?>